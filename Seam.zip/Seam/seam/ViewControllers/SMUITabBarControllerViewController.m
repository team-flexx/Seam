//
//  SMUITabBarControllerViewController.m
//  seam
//
//  Created by festusojo on 8/7/19.
//  Copyright © 2019 codepath. All rights reserved.
//

#import "SMUITabBarControllerViewController.h"

@interface SMUITabBarControllerViewController ()

@end

@implementation SMUITabBarControllerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.selectedIndex = 1;
}


@end
