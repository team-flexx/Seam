//
//  SwipingScreenViewController.h
//  seam
//
//  Created by laurenjle on 7/17/19.
//  Copyright © 2019 codepath. All rights reserved.
//

#import "SMFakeJobsDataManager.h"
#import "SMJobCard.h"
#import "SMJobListing.h"
#import "SMRealJobsDataManager.h"

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
//#import "SMJobCard.h"

@interface SwipingScreenViewController : UIViewController <MDCSwipeToChooseDelegate>


@end

NS_ASSUME_NONNULL_END
