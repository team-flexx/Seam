//
//  SMUITabBarControllerViewController.h
//  seam
//
//  Created by festusojo on 8/7/19.
//  Copyright © 2019 codepath. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SMUITabBarControllerViewController : UITabBarController

@end

NS_ASSUME_NONNULL_END
