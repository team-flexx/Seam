//
//  ProfileViewController.h
//  seam
//
//  Created by alexamorales on 7/18/19.
//  Copyright © 2019 codepath. All rights reserved.
//

#import "SMUserProfile.h"

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProfileViewController : UIViewController

@property SMUserProfile *userProfile;

@end

NS_ASSUME_NONNULL_END
