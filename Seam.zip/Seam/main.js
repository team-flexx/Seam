Parse.Cloud.define('hello', function(req, res){

res.success('Whats upppppppp');

}];


Parse.Cloud.define('friday', function(req, res){

res.success('yayy');

}];
